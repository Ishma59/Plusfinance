from django.apps import AppConfig


class SavingsConfig(AppConfig):
    name = 'savings'
