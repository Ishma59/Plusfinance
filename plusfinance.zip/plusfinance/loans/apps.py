from django.apps import AppConfig


class LoansConfig(AppConfig):
    name = 'loans'
