MicroFinance's documentation!
========================================


Introduction:
=============

This is MicroPyramid opensource initiative for microfinanace management.

This is full featured software to manage microfinanace Institute(s).


Technical Details
=================
* Framework : Django 1.7
* Programming language : Python 2.7
* Database : Mysql 5.6
* Test suite : Selinium Python

Features
========


Contents:

.. toctree::
   :maxdepth: 2



Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

